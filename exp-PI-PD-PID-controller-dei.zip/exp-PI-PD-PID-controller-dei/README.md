## Introduction


<b>Discipline | <b>Electrical Engineering 
:--|:--|
<b> Lab | <b> Control Engineering Virtual Laboratory (PCC-EE17)
<b> Experiment|     <b>4. Find and Plot the step and impulse response for a type ‘0’, type ‘1’, type ‘2’ systems

### About the Experiment 

Fill a brief description of this experiment here

<b>Name of Developer | <b> Dr. Rajeev Kumar Chauhan
:--|:--|
<b> Institute | <b>  Dayalbagh Educational Institute Agra
<b> Email id|     <b>  rkchauhan@dei.ac.in 
<b> Department |  Department of Electrical Engineering

### Contributors List

SrNo | Name | Faculty or Student | Department| Institute | Email id
:--|:--|:--|:--|:--|:--|
1 | Dr. Rajeev Kumar Chauhan | Faculty | Department of Electrical Engineering | Dayalbagh Educational Institute Agra | rkchauhan@dei.ac.in
2 | . | . | . | . | .

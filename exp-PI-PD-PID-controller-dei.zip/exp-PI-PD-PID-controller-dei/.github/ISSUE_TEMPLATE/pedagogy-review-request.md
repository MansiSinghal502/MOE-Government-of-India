---
name: Pedagogy Review Request
about: Get your pedagogy reviewed
title: Request for Review of Pedagogy
labels: pedagogy
assignees: ''

---

## *Pedagogy review Request*

1. *Exp Name*:<!--Fill the name of the experiment-->
2. *Domain*:<!-- Fill the domain/discipline that the experiment belongs to-->
3. *Lab Name*:<!-- Fill the name of the lab that the experiment belongs to-->
3. **Link to the pedagogy document**: { ../pedagogy/README.md]

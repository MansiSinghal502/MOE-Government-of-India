### This folder contains images used in round 3 documentation.

Study the effect of PI and PD Controller on system performance. 

		

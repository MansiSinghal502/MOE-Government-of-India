### Link your references in here
1. K.Ogata,“Modern Control Engineering” Prentice Hall of India.
2. Norman S.Nise, “Control System Engineering”, John Wiley & Sons.
3. M.Gopal, “Control Systems: Principles & Design” Tata McGraw Hill.

### Study the effect of PI, PD and PID Controller on system performance
<p style="margin-left:0px;"><strong>Select “Study the effect of PI Controller on system performance”</strong></p>
<p style="margin-left:0px;"><strong>9.1 Procedure: </strong></p>
<p style="margin-left:20px;"><strong>9.1.1 User Input:</strong></p>
        <p style="margin-left:30px;">9.1.1.1 Firstly, adjust the values of the coefficient c of the numerator polynomial by 
                         sliding the slider.<br>
          9.1.1.2 Now adjust the value of coefficients p, q and r of denominator polynomial by sliding
                         the other slider.<br>
          9.1.1.3 Press “Submit” button to submit the values of coefficients of numerator and 
                        denominator polynomial.</p>

<p style="margin-left:20px;"><strong>9.1.2 Calculations:</strong></p>
        <p style="margin-left:30px;">9.1.2.1 Click “Run” button to obtain input transfer function with the given coefficients.<br>
          9.1.2.2 Click on “Run” button again to obtain the step response of the transfer function.<br>
          9.1.2.3 Again, click on “Run” button to obtain the impulse response of the transfer function.</p>

<p style="margin-left:20px;"><strong>9.1.3 Results:</strong></p>
          <p style="margin-left:30px;">9.1.3.1  Once more, click on the “Run” button to obtain the effect of PI Controller for the input transfer function in the result section and the conclusion of the experiment in the Conclusions Section.</p>


<p style="margin-left:0px;"><strong>Select “Study the effect of PD Controller on system performance”</strong></p>
<p style="margin-left:0px;"><strong>9.2 Procedure: </strong></p>
<p style="margin-left:20px;"><strong>9.2.1 User Input:</strong></p>
        <p style="margin-left:30px;">9.2.1.1 Firstly, adjust the values of the coefficient c of the numerator polynomial by 
                         sliding the slider.<br>
          9.2.1.2 Now adjust the value of coefficients p, q and r of denominator polynomial by sliding
                         the other slider.<br>
          9.2.1.3 Press “Submit” button to submit the values of coefficients of numerator and 
                        denominator polynomial.</p>

<p style="margin-left:20px;"><strong>9.2.2 Calculations:</strong></p>
        <p style="margin-left:30px;">9.2.2.1 Click “Run” button to obtain input transfer function with the given coefficients.<br>
          9.2.2.2 Click on “Run” button again to obtain the step response of the transfer function.<br>
          9.2.2.3 Again, click on “Run” button to obtain the impulse response of the transfer function.</p>

<p style="margin-left:20px;"><strong>9.2.3 Results:</strong></p>
          <p style="margin-left:30px;">9.2.3.1  Once more, click on the “Run” button to obtain the effect of PD Controller for the input transfer function in the result section and the conclusion of the experiment in the Conclusions Section.</p>

<p style="margin-left:0px;"><strong>Select “Study the effect of PID Controller on system performance”</strong></p>
<p style="margin-left:0px;"><strong>9.3 Procedure: </strong></p>
<p style="margin-left:20px;"><strong>9.3.1 User Input:</strong></p>
        <p style="margin-left:30px;">9.3.1.1 Firstly, adjust the values of the coefficient c of the numerator polynomial by 
                         sliding the slider.<br>
          9.3.1.2 Now adjust the value of coefficients p, q and r of denominator polynomial by sliding
                         the other slider.<br>
          9.3.1.3 Press “Submit” button to submit the values of coefficients of numerator and 
                        denominator polynomial.</p>

<p style="margin-left:20px;"><strong>9.3.2 Calculations:</strong></p>
        <p style="margin-left:30px;">9.3.2.1 Click “Run” button to obtain input transfer function with the given coefficients.<br>
          9.3.2.2 Click on “Run” button again to obtain the step response of the transfer function.<br>
          9.3.2.3 Again, click on “Run” button to obtain the impulse response of the transfer function.</p>

<p style="margin-left:20px;"><strong>9.3.3 Results:</strong></p>
          <p style="margin-left:30px;">9.2.3.1  Once more, click on the “Run” button to obtain the effect of PID Controller for the input transfer function in the result section and the conclusion of the experiment in the Conclusions Section.</p>
